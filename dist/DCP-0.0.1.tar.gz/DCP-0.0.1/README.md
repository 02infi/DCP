# Deep cell predictor (DCP)
a deep learning approach that explicitly models changes in transcriptional variance using a combination of variational autoencoders and normalizing flows
